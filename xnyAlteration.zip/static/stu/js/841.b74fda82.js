"use strict";
(self["webpackChunkstu_project"] = self["webpackChunkstu_project"] || []).push([[841], {
    43841: function(e, s, t) {
        t.r(s),
        t.d(s, {
            default: function() {
                return _
            }
        });
        var l = function() {
            var e = this
              , s = e.$createElement
              , t = e._self._c || s;
            return t("div", {
                staticStyle: {
                    "overflow-x": "auto"
                }
            }, [e.list.length > 0 ? t("div", [t("a-directory-tree", {
                attrs: {
                    "default-selected-keys": e.treeId,
                    "replace-fields": e.replaceFields,
                    blockNode: ""
                },
                on: {
                    select: e.onSelect,
                    expand: e.onExpand
                }
            }, e._l(e.list, (function(s) {
                return t("a-tree-node", {
                    key: s.id,
                    class: [e.CourseIds.includes(s.id) ? "c-f0" : "c-00"]
                }, [t("span", {
                    class: [e.CourseIds.includes(s.id) ? "c-f0" : "c-00"],
                    attrs: {
                        slot: "title"
                    },
                    slot: "title"
                }, [e._v(" " + e._s(s.catalogName) + " ")]), e._l(s.childList, (function(s) {
                    return t("a-tree-node", {
                        key: s.id,
                        class: [e.CourseIds.includes(s.id) ? "c-f0" : "c-00"]
                    }, [t("span", {
                        class: [e.CourseIds.includes(s.id) ? "c-f0" : "c-00"],
                        attrs: {
                            slot: "title"
                        },
                        slot: "title"
                    }, [e._v(" " + e._s(s.catalogName) + " ")]), e._l(s.childList, (function(s) {
                        return t("a-tree-node", {
                            key: s.id,
                            class: [e.CourseIds.includes(s.id) ? "c-f0" : "c-00"]
                        }, [t("span", {
                            class: [e.CourseIds.includes(s.id) ? "c-f0" : "c-00"],
                            attrs: {
                                slot: "title"
                            },
                            slot: "title"
                        }, [e._v(" " + e._s(s.catalogName) + " ")]), e._l(s.childList, (function(s) {
                            return t("a-tree-node", {
                                key: s.id,
                                class: [e.CourseIds.includes(s.id) ? "c-f0" : "c-00"]
                            }, [t("span", {
                                class: [e.CourseIds.includes(s.id) ? "c-f0" : "c-00"],
                                attrs: {
                                    slot: "title"
                                },
                                slot: "title"
                            }, [e._v(" " + e._s(s.catalogName) + " ")]), e._l(s.childList, (function(s) {
                                return t("a-tree-node", {
                                    key: s.id,
                                    class: [e.CourseIds.includes(s.id) ? "c-f0" : "c-00"]
                                }, [t("span", {
                                    class: [e.CourseIds.includes(s.id) ? "c-f0" : "c-00"],
                                    attrs: {
                                        slot: "title"
                                    },
                                    slot: "title"
                                }, [e._v(" " + e._s(s.catalogName) + " ")]), e._l(s.childList, (function(s) {
                                    return t("a-tree-node", {
                                        key: s.id,
                                        class: [e.CourseIds.includes(s.id) ? "c-f0" : "c-00"]
                                    }, [t("span", {
                                        class: [e.CourseIds.includes(s.id) ? "c-f0" : "c-00"],
                                        attrs: {
                                            slot: "title"
                                        },
                                        slot: "title"
                                    }, [e._v(" " + e._s(s.catalogName) + " ")]), e._l(s.childList, (function(s) {
                                        return t("a-tree-node", {
                                            key: s.id,
                                            class: [e.CourseIds.includes(s.id) ? "c-f0" : "c-00"]
                                        }, [t("span", {
                                            class: [e.CourseIds.includes(s.id) ? "c-f0" : "c-00"],
                                            attrs: {
                                                slot: "title"
                                            },
                                            slot: "title"
                                        }, [e._v(" " + e._s(s.catalogName) + " ")]), e._l(s.childList, (function(s) {
                                            return t("a-tree-node", {
                                                key: s.id,
                                                class: [e.CourseIds.includes(s.id) ? "c-f0" : "c-00"]
                                            }, [t("span", {
                                                class: [e.CourseIds.includes(s.id) ? "c-f0" : "c-00"],
                                                attrs: {
                                                    slot: "title"
                                                },
                                                slot: "title"
                                            }, [e._v(" " + e._s(s.catalogName) + " ")]), e._l(s.childList, (function(s) {
                                                return t("a-tree-node", {
                                                    key: s.id,
                                                    class: [e.CourseIds.includes(s.id) ? "c-f0" : "c-00"]
                                                }, [t("span", {
                                                    class: [e.CourseIds.includes(s.id) ? "c-f0" : "c-00"],
                                                    attrs: {
                                                        slot: "title"
                                                    },
                                                    slot: "title"
                                                }, [e._v(" " + e._s(s.catalogName) + " ")]), e._l(s.childList, (function(s) {
                                                    return t("a-tree-node", {
                                                        key: s.id,
                                                        class: [e.CourseIds.includes(s.id) ? "c-f0" : "c-00"]
                                                    }, [t("span", {
                                                        class: [e.CourseIds.includes(s.id) ? "c-f0" : "c-00"],
                                                        attrs: {
                                                            slot: "title"
                                                        },
                                                        slot: "title"
                                                    }, [e._v(" " + e._s(s.catalogName) + " ")]), e._l(s.childList, (function(s) {
                                                        return t("a-tree-node", {
                                                            key: s.id,
                                                            class: [e.CourseIds.includes(s.id) ? "c-f0" : "c-00"]
                                                        }, [t("span", {
                                                            class: [e.CourseIds.includes(s.id) ? "c-f0" : "c-00"],
                                                            attrs: {
                                                                slot: "title"
                                                            },
                                                            slot: "title"
                                                        }, [e._v(" " + e._s(s.catalogName) + " ")])])
                                                    }
                                                    ))], 2)
                                                }
                                                ))], 2)
                                            }
                                            ))], 2)
                                        }
                                        ))], 2)
                                    }
                                    ))], 2)
                                }
                                ))], 2)
                            }
                            ))], 2)
                        }
                        ))], 2)
                    }
                    ))], 2)
                }
                ))], 2)
            }
            )), 1)], 1) : t("div", {
                staticClass: "noMsg"
            }, [e._v("目录数据加载中...")])])
        }
          , c = []
          , i = t(53296)
          , d = t(68354)
          , a = t(63517)
          , o = t.n(a)
          , n = {
            name: "Directory",
            props: ["treeId", "teacherId"],
            components: {},
            data() {
                return {
                    list: [],
                    replaceFields: {
                        children: "childList",
                        title: "catalogName",
                        key: "id"
                    },
                    CourseIds: [],
                    keyid: 0
                }
            },
            mounted() {
                let e = this;
                e.getPeparCatalog(e.teacherId);
                let s = localStorage.getItem("paperreddot");
                setTimeout((function() {
                    e.CourseIds = null == s || "undefined" == typeof s ? [] : JSON.parse(s).catalogIds
                }
                ), 500),
                e.$bus.on("changePaperReddot", (s => {
                    e.CourseIds = s.catalogIds
                }
                ))
            },
            methods: {
                getPeparCatalog(e) {
                    let s = this;
                    (0,
                    i.z4)(e).then((e => {
                        function extractIds(arr) {
                          let ids = {};

                          function recursiveExtract(list) {
                              list.forEach(item => {
                              ids[item.id]=item.catalogName.replace(/-副本/g, "")
                              if (item.childList && Array.isArray(item.childList)) {
                                recursiveExtract(item.childList);
                              }
                            });
                          }

                          recursiveExtract(arr);
                          return ids;
                        }
                        setTimeout(function() {
                          localStorage.setItem("nearTestSubject",JSON.stringify(extractIds(e.extra)));
                        }, 0);
                        s.list = e.extra
                    }
                    ))
                },
                onSelect(e, s) {
                    let t = this;
                    t.keyid != e[0] && (t.keyid = e[0],
                    t.$router.replace({
                        query: o()(this.$route.query, {
                            catalogId: t.keyid
                        })
                    }),
                    t.$bus.emit("CancelPaperSelect", !1),
                    t.$bus.emit("PausePlay"),
                    (0,
                    d.Md)())
                },
                onExpand() {
                    console.log("Trigger Expand")
                }
            }
        }
          , r = n
          , u = t(70713)
          , f = (0,
        u.Z)(r, l, c, !1, null, "93794d94", null)
          , _ = f.exports
    }
}]);
