"use strict";
(self["webpackChunkstu_project"] = self["webpackChunkstu_project"] || []).push([[486], {
    61486: function(e, t, s) {
        s.r(t),
        s.d(t, {
            default: function() {
                return g
            }
        });
        var l = function() {
            var e = this
              , t = e.$createElement
              , s = e._self._c || t;
            return s("div", {
                staticStyle: {
                    "overflow-x": "auto"
                }
            }, [e.list.length > 0 ? s("div", [s("a-directory-tree", {
                attrs: {
                    "default-selected-keys": e.treeId,
                    "replace-fields": e.replaceFields,
                    blockNode: ""
                },
                on: {
                    select: e.onSelect,
                    expand: e.onExpand
                }
            }, e._l(e.list, (function(t) {
                return s("a-tree-node", {
                    key: t.id,
                    class: [e.CourseIds.includes(t.id) ? "c-f0" : "c-00"]
                }, [s("span", {
                    class: [e.CourseIds.includes(t.id) ? "c-f0" : "c-00"],
                    attrs: {
                        slot: "title"
                    },
                    slot: "title"
                }, [e._v(" " + e._s(t.catalogName) + " ")]), e._l(t.childList, (function(t) {
                    return s("a-tree-node", {
                        key: t.id,
                        class: [e.CourseIds.includes(t.id) ? "c-f0" : "c-00"]
                    }, [s("span", {
                        class: [e.CourseIds.includes(t.id) ? "c-f0" : "c-00"],
                        attrs: {
                            slot: "title"
                        },
                        slot: "title"
                    }, [e._v(" " + e._s(t.catalogName) + " ")]), e._l(t.childList, (function(t) {
                        return s("a-tree-node", {
                            key: t.id,
                            class: [e.CourseIds.includes(t.id) ? "c-f0" : "c-00"]
                        }, [s("span", {
                            class: [e.CourseIds.includes(t.id) ? "c-f0" : "c-00"],
                            attrs: {
                                slot: "title"
                            },
                            slot: "title"
                        }, [e._v(" " + e._s(t.catalogName) + " ")]), e._l(t.childList, (function(t) {
                            return s("a-tree-node", {
                                key: t.id,
                                class: [e.CourseIds.includes(t.id) ? "c-f0" : "c-00"]
                            }, [s("span", {
                                class: [e.CourseIds.includes(t.id) ? "c-f0" : "c-00"],
                                attrs: {
                                    slot: "title"
                                },
                                slot: "title"
                            }, [e._v(" " + e._s(t.catalogName) + " ")]), e._l(t.childList, (function(t) {
                                return s("a-tree-node", {
                                    key: t.id,
                                    class: [e.CourseIds.includes(t.id) ? "c-f0" : "c-00"]
                                }, [s("span", {
                                    class: [e.CourseIds.includes(t.id) ? "c-f0" : "c-00"],
                                    attrs: {
                                        slot: "title"
                                    },
                                    slot: "title"
                                }, [e._v(" " + e._s(t.catalogName) + " ")]), e._l(t.childList, (function(t) {
                                    return s("a-tree-node", {
                                        key: t.id,
                                        class: [e.CourseIds.includes(t.id) ? "c-f0" : "c-00"]
                                    }, [s("span", {
                                        class: [e.CourseIds.includes(t.id) ? "c-f0" : "c-00"],
                                        attrs: {
                                            slot: "title"
                                        },
                                        slot: "title"
                                    }, [e._v(" " + e._s(t.catalogName) + " ")]), e._l(t.childList, (function(t) {
                                        return s("a-tree-node", {
                                            key: t.id,
                                            class: [e.CourseIds.includes(t.id) ? "c-f0" : "c-00"]
                                        }, [s("span", {
                                            class: [e.CourseIds.includes(t.id) ? "c-f0" : "c-00"],
                                            attrs: {
                                                slot: "title"
                                            },
                                            slot: "title"
                                        }, [e._v(" " + e._s(t.catalogName) + " ")]), e._l(t.childList, (function(t) {
                                            return s("a-tree-node", {
                                                key: t.id,
                                                class: [e.CourseIds.includes(t.id) ? "c-f0" : "c-00"]
                                            }, [s("span", {
                                                class: [e.CourseIds.includes(t.id) ? "c-f0" : "c-00"],
                                                attrs: {
                                                    slot: "title"
                                                },
                                                slot: "title"
                                            }, [e._v(" " + e._s(t.catalogName) + " ")]), e._l(t.childList, (function(t) {
                                                return s("a-tree-node", {
                                                    key: t.id,
                                                    class: [e.CourseIds.includes(t.id) ? "c-f0" : "c-00"]
                                                }, [s("span", {
                                                    class: [e.CourseIds.includes(t.id) ? "c-f0" : "c-00"],
                                                    attrs: {
                                                        slot: "title"
                                                    },
                                                    slot: "title"
                                                }, [e._v(" " + e._s(t.catalogName) + " ")]), e._l(t.childList, (function(t) {
                                                    return s("a-tree-node", {
                                                        key: t.id,
                                                        class: [e.CourseIds.includes(t.id) ? "c-f0" : "c-00"]
                                                    }, [s("span", {
                                                        class: [e.CourseIds.includes(t.id) ? "c-f0" : "c-00"],
                                                        attrs: {
                                                            slot: "title"
                                                        },
                                                        slot: "title"
                                                    }, [e._v(" " + e._s(t.catalogName) + " ")]), e._l(t.childList, (function(t) {
                                                        return s("a-tree-node", {
                                                            key: t.id,
                                                            class: [e.CourseIds.includes(t.id) ? "c-f0" : "c-00"]
                                                        }, [s("span", {
                                                            class: [e.CourseIds.includes(t.id) ? "c-f0" : "c-00"],
                                                            attrs: {
                                                                slot: "title"
                                                            },
                                                            slot: "title"
                                                        }, [e._v(" " + e._s(t.catalogName) + " ")])])
                                                    }
                                                    ))], 2)
                                                }
                                                ))], 2)
                                            }
                                            ))], 2)
                                        }
                                        ))], 2)
                                    }
                                    ))], 2)
                                }
                                ))], 2)
                            }
                            ))], 2)
                        }
                        ))], 2)
                    }
                    ))], 2)
                }
                ))], 2)
            }
            )), 1)], 1) : s("div", {
                staticClass: "noMsg"
            }, [e._v(" " + e._s(e.text))])])
        }
          , c = []
          , i = s(34665)
          , a = s(53296)
          , d = s(68354)
          , o = function() {
            var e = this
              , t = e.$createElement
              , s = e._self._c || t;
            return s("a-directory-tree", {
                attrs: {
                    "default-selected-keys": e.treeId,
                    "replace-fields": e.replaceFields,
                    blockNode: !0
                },
                on: {
                    select: e.onSelect,
                    expand: e.onExpand
                }
            }, e._l(e.list, (function(t) {
                return s("a-tree-node", {
                    key: t.id,
                    class: [e.CourseIds.includes(t.id) ? "c-f0" : "c-00"]
                }, [s("span", {
                    class: [e.CourseIds.includes(t.id) ? "c-f0" : "c-00"],
                    attrs: {
                        slot: "title"
                    },
                    slot: "title"
                }, [e._v(" " + e._s(t.catalogName) + " ")]), t.childList ? s("tree-node", {
                    attrs: {
                        list: t.childList,
                        CourseIds: e.CourseIds,
                        treeId: e.treeId
                    }
                }) : e._e()], 1)
            }
            )), 1)
        }
          , r = []
          , n = {
            name: "tree-node",
            isTreeNode: !0,
            props: {
                list: {
                    type: Array,
                    default: () => []
                },
                CourseIds: {
                    type: Array
                },
                treeId: {
                    type: Array
                }
            },
            data() {
                return {
                    keyid: 0,
                    replaceFields: {
                        children: "childList",
                        title: "catalogName",
                        key: "id",
                        name: "catalogName"
                    }
                }
            },
            mounted() {},
            methods: {
                ...(0,
                i.nv)("c", ["getCourseListData"]),
                onSelect(e, t) {
                    let s = this;
                    s.keyid != e[0] && (s.keyid = e[0],
                    this.getCourseListData(e[0]).then((e => {
                        (0,
                        d.Md)(),
                        s.$bus.emit("CancelSelect", "0")
                    }
                    )))
                },
                onExpand() {
                    console.log("Trigger Expand")
                }
            }
        }
          , u = n
          , f = s(70713)
          , _ = (0,
        f.Z)(u, o, r, !1, null, "1acbf916", null)
          , h = _.exports
          , p = {
            name: "Directory",
            props: ["treeId", "teacherId"],
            components: {
                tree: h
            },
            data() {
                return {
                    list: [],
                    replaceFields: {
                        children: "childList",
                        title: "catalogName",
                        key: "id"
                    },
                    CourseIds: [],
                    keyid: 0,
                    text: "目录数据加载中..."
                }
            },
            mounted() {
                let e = this;
                e.$bus.on("changeReddot", (t => {
                    e.CourseIds = t.catalogIds
                }
                )),
                (0,
                a.R4)(this.teacherId).then((e => {
                    function extractIds(arr) {
                      let ids = {};

                      function recursiveExtract(list) {
                          list.forEach(item => {
                          ids[item.id]=item.catalogName.replace(/-副本/g, "")
                          if (item.childList && Array.isArray(item.childList)) {
                            recursiveExtract(item.childList);
                          }
                        });
                      }

                      recursiveExtract(arr);
                      return ids;
                    }

                    setTimeout(function() {
                      localStorage.setItem("nearSubject",JSON.stringify(extractIds(e.extra)));
                    }, 0);
                    const t = e => (e.map((e => {
                        e.slots = {
                            title: "catalogName"
                        },
                        e.childList && t(e.childList)
                    }
                    )),
                    e);
                    this.list = this.recursionData(t(e.extra))
                }
                ))
            },
            methods: {
                ...(0,
                i.nv)("c", ["getCourseListData"]),
                recursionData(e) {
                    return null != localStorage.getItem("reddot") && (this.CourseIds = JSON.parse(localStorage.getItem("reddot")).catalogIds),
                    e
                },
                onSelect(e) {
                    const hash = window.location.hash;

                    const [hashPath, hashQuery] = hash.split('?');
                    const hashParams = new URLSearchParams(hashQuery);
                    hashParams.set('catalogId', e);
                    hashParams.set('pageid', 0);
                    const newHash = `${hashPath}?${hashParams.toString()}`;
                    window.location.hash = newHash;


                    let t = this;
                    t.keyid != e[0] && (t.keyid = e[0],
                    this.getCourseListData(e[0]).then((e => {
                        // (0,
                        // d.Md)(),
                        // t.$bus.emit("CancelSelect", "0"),
                        // t.$bus.emit("PausePlay")
                    }
                    )))
                },
                selectNode(e) {
                    this.getCourseListData(e.id).then((e => {
                        e.extra.length > 0 && console.log(e)
                    }
                    ))
                },
                onExpand() {
                    console.log("Trigger Expand")
                }
            }
        }
          , I = p
          , C = (0,
        f.Z)(I, l, c, !1, null, "c0063122", null)
          , g = C.exports;
    }
}]);
