sudo apt install wkhtmltopdf
sudo apt-get install fonts-noto-cjk
pip install "flask[async]"
pip install beautifulsoup4
pip install requests
pip install mimetypes
pip install pdfkit
pip install uwsgi
pip install aiohttper